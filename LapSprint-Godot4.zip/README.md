# Lap Sprint — Godot 4.3 starter project

This is a small, playable 3D racing milestone made with GDScript and Godot's built-in placeholder meshes. The car, road, barriers, markings, HUD, and touch icons are all included in this project. No add-ons or downloaded art are required.

The project uses Godot's Compatibility renderer so the same lightweight scene can run on Windows and Android devices compatible with the requested minimum API level.

## Open and play

1. Install Godot 4.3 or a compatible Godot 4.x release.
2. In Project Manager, choose **Import** and select this folder's `project.godot` file.
3. Open the project. Let Godot finish importing the SVG touch icons.
4. Press **F5** to run the main scene.
5. Wait for **3, 2, 1, GO!**, then drive around the rectangular circuit in the checkpoint order shown below.

### Controls

| Action | Keyboard |
| --- | --- |
| Accelerate | W or Up Arrow |
| Brake; reverse below 2 m/s | S or Down Arrow |
| Steer left | A or Left Arrow |
| Steer right | D or Right Arrow |
| Handbrake | Space |
| Reset to the start, lifted 2 m | R |
| Pause or resume | Esc |

On Android, on-screen left, right, accelerate, brake, and handbrake buttons appear. They send the same named input actions as the keyboard. The touch controls hide on desktop.

## Scene tree

```text
Main (Node3D, race_manager.gd)
├── WorldEnvironment
├── Sun (DirectionalLight3D)
├── Track (instance of tracks/test_track.tscn)
│   ├── Floor (StaticBody3D)
│   ├── Infield (visual PlaneMesh)
│   ├── RoadMarkings
│   ├── Barriers (four StaticBody3D walls)
│   └── Checkpoints (three ordered Area3D gates and a finish gate)
├── SportsCar (instance of vehicles/sports_car.tscn)
│   ├── ChassisCollision
│   ├── BodyVisuals
│   ├── FrontLeft (VehicleWheel3D)
│   ├── FrontRight (VehicleWheel3D)
│   ├── RearLeft (VehicleWheel3D)
│   └── RearRight (VehicleWheel3D)
├── ChaseCamera (Node3D, chase_camera.gd)
│   └── SpringArm3D
│       └── Camera3D
├── HUD (instance of ui/hud.tscn, CanvasLayer)
└── MobileControls (instance of ui/mobile_controls.tscn, CanvasLayer)
```

## Recreate or inspect the scenes in the editor

The `.tscn` files already contain these nodes and settings. This list is useful if you want to rebuild them by hand or inspect the Inspector values.

### Sports car — `scenes/vehicles/sports_car.tscn`

1. Create a `VehicleBody3D` named `SportsCar` and attach `scripts/vehicles/car_controller.gd`.
2. Set **Mass** to `1500`, **Center of Mass Mode** to `Custom`, and **Center of Mass** to `(0, -0.9, 0)`. Set **Collision Layer** to `2` and **Collision Mask** to `5`.
3. Add a `CollisionShape3D` with a `BoxShape3D` sized `(1.8, 0.6, 4.0)`, positioned at `(0, -0.1, 0)`.
4. Add simple `MeshInstance3D` boxes for the body and cabin. The included body uses a red BoxMesh and a dark blue BoxMesh for the cabin.
5. Add four `VehicleWheel3D` children. Use the transforms and wheel roles below. Each wheel has a CylinderMesh child named `WheelMesh`, positioned at `(0, -0.15, 0)` and rotated 90 degrees around Z so its axle points across the car.

| Wheel | Position | Steering | Traction |
| --- | --- | --- | --- |
| FrontLeft | `(-0.92, -0.7, -1.35)` | On | Off |
| FrontRight | `(0.92, -0.7, -1.35)` | On | Off |
| RearLeft | `(-0.92, -0.7, 1.35)` | Off | On |
| RearRight | `(0.92, -0.7, 1.35)` | Off | On |

For all four wheels, set **Radius** `0.4`, **Rest Length** `0.15`, **Suspension Travel** `0.2`, **Suspension Stiffness** `60`, **Compression Damping** `3.5`, **Relaxation Damping** `3.5`, **Friction Slip** `1.2`, and **Roll Influence** `0.1`.

### Test track — `scenes/tracks/test_track.tscn`

1. Create a `StaticBody3D` named `Floor`, with a `CollisionShape3D` using a `BoxShape3D` sized `(200, 0.2, 200)` at `(0, -0.1, 0)`.
2. Add a `MeshInstance3D` to `Floor` with a `PlaneMesh` sized `(200, 200)`. Give the asphalt StandardMaterial3D a roughness of `0.42`.
3. Add an infield PlaneMesh sized `(136, 136)` at Y `0.012`, and white box markings at X/Z `±68` and `±92`. These make the rectangular circuit visible against the placeholder surface.
4. Add four `StaticBody3D` barriers, each 2 m high. The north and south walls use a `(200, 2, 1)` box; the east and west walls use `(1, 2, 198)` boxes. Their centers are `(0, 1, -99.5)`, `(0, 1, 99.5)`, `(-99.5, 1, 0)`, and `(99.5, 1, 0)`.
5. Add a white BoxMesh sized `(10, 0.2, 1)` at `(0, 0.11, 80)`, rotated 90 degrees around Y.
6. Add a `Node3D` named `Checkpoints`, then add the three checkpoint `Area3D` gates and finish gate using `scripts/tracks/checkpoint.gd`. Each area has `Collision Layer = 0` and `Collision Mask = 2`.

The lap order follows the track ring: start at the south side facing east; checkpoint 1 is on the east side `(80, 1, 0)`; checkpoint 2 is on the north side `(0, 1, -80)`; checkpoint 3 is on the west side `(-80, 1, 0)`; cross the finish gate at `(0, 1, 80)`. The finish line only advances the lap after all three checkpoints have been reached in order.

### Main scene and camera

`scenes/main.tscn` instances the track, car, HUD, and mobile controls. The car starts at `(-8, 1.25, 80)` with Y rotation `-90°`. The camera rig is a sibling of the car so it can smoothly follow the car's position and heading.

For the camera, use a `Node3D` with `scripts/camera/chase_camera.gd`, followed by a `SpringArm3D` and `Camera3D`. Set the rig's exported **Follow Speed** to `5`, **Target Height** to `1.6`, and **Target Path** to `../SportsCar`. Set the spring arm length to `6`, margin to `0.1`, and collision mask to `5`; the script excludes the car from the sweep. Set the Camera3D FOV to `70°`.

### HUD and mobile controls

The HUD is a `CanvasLayer` with a `Control` root, a speed/time/lap/position panel, centered countdown, and a full-screen pause/results overlay. `scripts/ui/race_hud.gd` updates labels and exposes Resume and Restart signals.

The mobile-control scene is a `CanvasLayer`. Its script creates five `TouchScreenButton` nodes, sizes them from the viewport, and hides the layer unless `OS.has_feature("mobile")` is true.

## Race behavior

- The race begins with a 3-second countdown. Car input is disabled until **GO!**.
- The HUD shows speed in km/h, elapsed race time, current lap out of three, and position `1 / 1`.
- Passing the checkpoints out of order does not count. Crossing a finish line early does not count.
- Pressing R, falling below Y `-10`, or being upside down for 2 seconds resets the car. Resetting sends it back to the start, 2 m above the track, clears its velocities, and clears checkpoint progress for the current lap.
- Esc opens the pause overlay. The results overlay appears after lap three and shows the final time.

## Collision layers

| Layer | Name | Used by |
| --- | --- | --- |
| 1 | Track | Track floor |
| 2 | Car | SportsCar body and checkpoint detection |
| 3 | Barriers | Four perimeter walls |

The car mask is `5` (layers 1 and 3). Barriers use layer `4` and mask `3` (layers 1 and 2). Checkpoint areas use mask `2` so they only detect the car.

## Export

### Windows

For local play, open the project and press **F5**. To make a standalone Windows build, install the matching Godot export templates, open **Project > Export**, add **Windows Desktop**, then choose **Export Project** and an `.exe` destination.

### Android

1. Install the Android export templates that match your Godot version.
2. Install OpenJDK 17 and the Android SDK. In Godot, open **Editor > Editor Settings > Export > Android** and set **Java SDK Path** and **Android SDK Path**.
3. Open **Project > Export**, add an **Android** preset, and set the unique package name to `com.racing.game`.
4. If you need to explicitly set Minimum SDK 23, install the Android Gradle build template from the **Project** menu, enable **Gradle Build** in the Android preset, then set **Gradle Build > Min SDK** to `23`.
5. Choose **Export Project** and save an `.apk` for device installation. A debug export is suitable for local testing. For a store release, configure a release keystore and follow the store's signing requirements.

Godot 4.3's Android setup and Gradle steps are documented at [Exporting for Android](https://docs.godotengine.org/en/4.3/tutorials/export/exporting_for_android.html) and [Gradle builds for Android](https://docs.godotengine.org/en/4.3/tutorials/export/android_gradle_build.html).

## Project files

```text
project.godot
scenes/main.tscn
scenes/vehicles/sports_car.tscn
scenes/tracks/test_track.tscn
scenes/ui/hud.tscn
scenes/ui/mobile_controls.tscn
scripts/vehicles/car_controller.gd
scripts/camera/chase_camera.gd
scripts/ui/race_hud.gd
scripts/ui/mobile_controls.gd
scripts/managers/race_manager.gd
scripts/tracks/checkpoint.gd
assets/ui/*.svg
```

VehicleBody3D is used for this first milestone as requested. Its physics are intentionally simple and use placeholder art; the car controller comment describes the planned Phase 2 move to a custom RayCast3D/RigidBody3D vehicle for finer drift tuning.
