extends Node3D
## Owns the countdown, ordered checkpoints, lap count, timer, pause, and results.

const TOTAL_LAPS: int = 3

@onready var car: VehicleBody3D = $SportsCar
@onready var hud: CanvasLayer = $HUD
@onready var checkpoints: Node = $Track/Checkpoints

var countdown_seconds: float = 3.0
var countdown_value: int = 3
var race_started: bool = false
var race_finished: bool = false
var race_paused: bool = false
var elapsed_seconds: float = 0.0
var completed_laps: int = 0
var next_checkpoint_index: int = 0
var checkpoint_count: int = 0


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	car.set("controls_enabled", false)
	car.connect("reset_completed", Callable(self, "_on_car_reset"))
	hud.connect("resume_requested", Callable(self, "_resume_race"))
	hud.connect("restart_requested", Callable(self, "_restart_race"))

	for checkpoint: Node in checkpoints.get_children():
		checkpoint.connect("body_passed", Callable(self, "_on_checkpoint_passed"))
		if not checkpoint.get("is_finish_line"):
			checkpoint_count += 1

	hud.call("set_lap", 1, TOTAL_LAPS)
	hud.call("set_countdown", "3")


func _process(delta: float) -> void:
	hud.call("set_speed", car.linear_velocity.length() * 3.6)

	if not race_started and not race_finished and not race_paused:
		countdown_seconds -= delta
		var next_value: int = maxi(1, ceili(countdown_seconds))
		if next_value != countdown_value and countdown_seconds > 0.0:
			countdown_value = next_value
			hud.call("set_countdown", str(countdown_value))
		if countdown_seconds <= 0.0:
			_start_race()
	elif race_started and not race_finished and not race_paused:
		elapsed_seconds += delta
		hud.call("set_race_time", elapsed_seconds)


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("pause") and race_started and not race_finished:
		_set_paused(not race_paused)
		get_viewport().set_input_as_handled()


func _start_race() -> void:
	race_started = true
	car.set("controls_enabled", true)
	hud.call("set_countdown", "GO!")
	get_tree().create_timer(0.75, true, false, true).timeout.connect(Callable(self, "_hide_countdown"))


func _hide_countdown() -> void:
	if not race_finished:
		hud.call("set_countdown", "")


func _on_checkpoint_passed(index: int, is_finish_line: bool, body: Node3D) -> void:
	if body != car or not race_started or race_finished or race_paused:
		return

	if is_finish_line:
		if next_checkpoint_index != checkpoint_count:
			return
		completed_laps += 1
		next_checkpoint_index = 0
		if completed_laps >= TOTAL_LAPS:
			_finish_race()
		else:
			hud.call("set_lap", completed_laps + 1, TOTAL_LAPS)
	elif index == next_checkpoint_index:
		next_checkpoint_index += 1


func _on_car_reset() -> void:
	next_checkpoint_index = 0


func _finish_race() -> void:
	race_finished = true
	car.set("controls_enabled", false)
	hud.call("set_lap", TOTAL_LAPS, TOTAL_LAPS)
	hud.call("show_results", elapsed_seconds)


func _set_paused(value: bool) -> void:
	race_paused = value
	get_tree().paused = value
	if value:
		hud.call("show_pause")
	else:
		hud.call("hide_overlay")


func _resume_race() -> void:
	if race_paused:
		_set_paused(false)


func _restart_race() -> void:
	get_tree().paused = false
	get_tree().reload_current_scene()
