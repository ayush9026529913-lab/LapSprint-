extends VehicleBody3D
## Simple rear-wheel-drive controller for the first playable milestone.
## Phase 2 can replace VehicleBody3D with a custom RigidBody3D plus four RayCast3D
## wheels for more direct drift and tire-grip control.

signal reset_completed

const MAX_ENGINE_FORCE: float = 1200.0
const MAX_BRAKE_FORCE: float = 120.0
const MAX_STEER_ANGLE: float = 0.35
const HANDBRAKE_FORCE: float = MAX_BRAKE_FORCE * 3.0
const STEER_RESPONSE: float = 2.8

@export var controls_enabled: bool = false

@onready var front_left: VehicleWheel3D = $FrontLeft
@onready var front_right: VehicleWheel3D = $FrontRight
@onready var rear_left: VehicleWheel3D = $RearLeft
@onready var rear_right: VehicleWheel3D = $RearRight

var _start_position: Vector3
var _start_yaw: float
var _upside_down_seconds: float = 0.0
var _reset_pending: bool = false


func _ready() -> void:
	add_to_group("player_car")
	center_of_mass_mode = RigidBody3D.CENTER_OF_MASS_MODE_CUSTOM
	center_of_mass = Vector3(0.0, -0.9, 0.0)
	continuous_cd = true
	_start_position = global_position
	_start_yaw = rotation.y
	set_physics_process(true)


func _physics_process(delta: float) -> void:
	if Input.is_action_just_pressed("reset_car"):
		_schedule_reset()

	if global_position.y < -10.0:
		_schedule_reset()

	if global_transform.basis.y.dot(Vector3.UP) < 0.2:
		_upside_down_seconds += delta
		if _upside_down_seconds >= 2.0:
			_schedule_reset()
	else:
		_upside_down_seconds = 0.0

	_update_controls(delta)
	_update_wheel_visuals(delta)


func _update_controls(delta: float) -> void:
	if not controls_enabled:
		engine_force = 0.0
		brake = MAX_BRAKE_FORCE
		_set_rear_wheel_brakes(0.0)
		steering = move_toward(steering, 0.0, STEER_RESPONSE * delta)
		return

	var steering_input: float = Input.get_action_strength("steer_left") - Input.get_action_strength("steer_right")
	var target_steering: float = steering_input * MAX_STEER_ANGLE
	steering = move_toward(steering, target_steering, STEER_RESPONSE * delta)

	var throttle: float = Input.get_action_strength("accelerate")
	var brake_input: float = Input.get_action_strength("brake")
	var handbrake_pressed: bool = Input.is_action_pressed("handbrake")
	var speed_mps: float = linear_velocity.length()

	if handbrake_pressed:
		engine_force = throttle * MAX_ENGINE_FORCE
		brake = 0.0
		_set_rear_wheel_brakes(HANDBRAKE_FORCE)
	elif brake_input > 0.0:
		_set_rear_wheel_brakes(0.0)
		if speed_mps < 2.0:
			# S / Down becomes reverse once the car is moving slowly.
			engine_force = -brake_input * MAX_ENGINE_FORCE
			brake = 0.0
		else:
			engine_force = 0.0
			brake = brake_input * MAX_BRAKE_FORCE
	else:
		_set_rear_wheel_brakes(0.0)
		engine_force = throttle * MAX_ENGINE_FORCE
		brake = 0.0


func _set_rear_wheel_brakes(force: float) -> void:
	rear_left.brake = force
	rear_right.brake = force


func _update_wheel_visuals(delta: float) -> void:
	for wheel: VehicleWheel3D in [front_left, front_right, rear_left, rear_right]:
		var wheel_mesh: Node3D = wheel.get_node_or_null("WheelMesh") as Node3D
		if wheel_mesh != null:
			var radians_per_second: float = wheel.get_rpm() * TAU / 60.0
			wheel_mesh.rotate_object_local(Vector3.RIGHT, radians_per_second * delta)


func reset_car() -> void:
	_schedule_reset()


func _schedule_reset() -> void:
	if _reset_pending:
		return
	_reset_pending = true
	call_deferred("_perform_reset")


func _perform_reset() -> void:
	var new_transform: Transform3D = Transform3D(Basis(Vector3.UP, _start_yaw), _start_position + Vector3.UP * 2.0)
	global_transform = new_transform
	linear_velocity = Vector3.ZERO
	angular_velocity = Vector3.ZERO
	steering = 0.0
	engine_force = 0.0
	brake = 0.0
	_set_rear_wheel_brakes(0.0)
	sleeping = false
	_upside_down_seconds = 0.0
	_reset_pending = false
	reset_completed.emit()
