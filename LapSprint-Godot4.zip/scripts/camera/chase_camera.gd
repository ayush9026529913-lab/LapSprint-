extends Node3D
## Smooth third-person camera. The spring arm performs the barrier collision sweep.

@export var target_path: NodePath
@export var follow_speed: float = 5.0
@export var target_height: float = 1.6

@onready var spring_arm: SpringArm3D = $SpringArm3D

var _target: Node3D


func _ready() -> void:
	_target = get_node_or_null(target_path) as Node3D
	if _target != null:
		var target_body: CollisionObject3D = _target as CollisionObject3D
		if target_body != null:
			spring_arm.add_excluded_object(target_body.get_rid())


func _process(delta: float) -> void:
	if _target == null:
		return

	var blend: float = clampf(follow_speed * delta, 0.0, 1.0)
	var follow_position: Vector3 = _target.global_position + Vector3.UP * target_height
	global_position = global_position.lerp(follow_position, blend)
	global_rotation = Vector3(
		lerp_angle(global_rotation.x, 0.0, blend),
		lerp_angle(global_rotation.y, _target.global_rotation.y, blend),
		lerp_angle(global_rotation.z, 0.0, blend)
	)
