extends Area3D
## Sends one event when the player car enters this checkpoint volume.

signal body_passed(checkpoint_index: int, is_finish_line: bool, body: Node3D)

@export var checkpoint_index: int = -1
@export var is_finish_line: bool = false


func _ready() -> void:
	body_entered.connect(_on_body_entered)


func _on_body_entered(body: Node3D) -> void:
	if body.is_in_group("player_car"):
		body_passed.emit(checkpoint_index, is_finish_line, body)
