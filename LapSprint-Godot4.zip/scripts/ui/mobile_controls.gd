extends CanvasLayer
## Builds large touch buttons that send the same actions as the keyboard.

const BUTTON_FILES: Dictionary = {
	"steer_left": "res://assets/ui/steer_left.svg",
	"steer_right": "res://assets/ui/steer_right.svg",
	"accelerate": "res://assets/ui/accelerate.svg",
	"brake": "res://assets/ui/brake.svg",
	"handbrake": "res://assets/ui/handbrake.svg",
}

var _buttons: Dictionary = {}


func _ready() -> void:
	visible = OS.has_feature("mobile")
	if not visible:
		return

	for action_name: String in BUTTON_FILES.keys():
		var button: TouchScreenButton = TouchScreenButton.new()
		button.name = action_name.capitalize()
		button.action = action_name
		button.texture_normal = load(BUTTON_FILES[action_name]) as Texture2D
		button.visibility_mode = TouchScreenButton.VISIBILITY_ALWAYS
		button.passby_press = true
		var touch_shape: CircleShape2D = CircleShape2D.new()
		touch_shape.radius = 58.0
		button.shape = touch_shape
		button.shape_visible = false
		add_child(button)
		_buttons[action_name] = button

	get_viewport().size_changed.connect(_layout_buttons)
	_layout_buttons()


func _layout_buttons() -> void:
	if _buttons.is_empty():
		return

	var screen: Vector2 = get_viewport().get_visible_rect().size
	var diameter: float = clampf(minf(screen.x, screen.y) * 0.15, 84.0, 124.0)
	var scale_value: float = diameter / 128.0
	var bottom_y: float = screen.y - diameter * 0.82
	var positions: Dictionary

	if screen.x >= screen.y:
		positions = {
			"steer_left": Vector2(diameter * 0.82, bottom_y),
			"steer_right": Vector2(diameter * 1.95, bottom_y),
			"brake": Vector2(screen.x - diameter * 1.95, bottom_y),
			"accelerate": Vector2(screen.x - diameter * 0.82, bottom_y),
			"handbrake": Vector2(screen.x - diameter * 0.82, bottom_y - diameter * 1.18),
		}
	else:
		positions = {
			"steer_left": Vector2(diameter * 0.82, bottom_y),
			"steer_right": Vector2(diameter * 0.82, bottom_y - diameter * 1.18),
			"brake": Vector2(screen.x - diameter * 0.82, bottom_y),
			"accelerate": Vector2(screen.x - diameter * 0.82, bottom_y - diameter * 1.18),
			"handbrake": Vector2(screen.x - diameter * 1.95, bottom_y),
		}

	for action_name: String in positions:
		var button: TouchScreenButton = _buttons[action_name] as TouchScreenButton
		button.position = positions[action_name]
		button.scale = Vector2.ONE * scale_value
