extends CanvasLayer
## Updates the compact race HUD and the pause/results overlay.

signal resume_requested
signal restart_requested

@onready var speed_value: Label = $UI/StatsPanel/Stats/SpeedValue
@onready var timer_value: Label = $UI/StatsPanel/Stats/TimerValue
@onready var lap_value: Label = $UI/StatsPanel/Stats/LapValue
@onready var position_value: Label = $UI/StatsPanel/Stats/PositionValue
@onready var countdown_label: Label = $UI/Countdown
@onready var overlay: ColorRect = $UI/Overlay
@onready var overlay_title: Label = $UI/Overlay/Panel/Content/Title
@onready var overlay_time: Label = $UI/Overlay/Panel/Content/Time
@onready var resume_button: Button = $UI/Overlay/Panel/Content/ResumeButton
@onready var restart_button: Button = $UI/Overlay/Panel/Content/RestartButton


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	resume_button.pressed.connect(_on_resume_pressed)
	restart_button.pressed.connect(_on_restart_pressed)
	set_race_time(0.0)
	set_speed(0.0)
	set_position(1, 1)
	hide_overlay()


func set_speed(speed_kmh: float) -> void:
	speed_value.text = "%03d KM/H" % int(round(speed_kmh))


func set_race_time(seconds: float) -> void:
	var minutes: int = int(seconds / 60.0)
	var remainder: float = fmod(seconds, 60.0)
	timer_value.text = "%02d:%05.2f" % [minutes, remainder]


func set_lap(current_lap: int, total_laps: int) -> void:
	lap_value.text = "LAP %d / %d" % [current_lap, total_laps]


func set_position(position: int, total_positions: int) -> void:
	position_value.text = "POSITION %d / %d" % [position, total_positions]


func set_countdown(value: String) -> void:
	countdown_label.text = value
	countdown_label.visible = not value.is_empty()


func show_pause() -> void:
	overlay_time.text = ""
	overlay_title.text = "PAUSED"
	resume_button.visible = true
	resume_button.grab_focus()
	overlay.visible = true


func show_results(final_time: float) -> void:
	var minutes: int = int(final_time / 60.0)
	var remainder: float = fmod(final_time, 60.0)
	overlay_title.text = "RACE COMPLETE"
	overlay_time.text = "FINAL TIME  %02d:%05.2f" % [minutes, remainder]
	resume_button.visible = false
	restart_button.grab_focus()
	overlay.visible = true


func hide_overlay() -> void:
	overlay.visible = false


func _on_resume_pressed() -> void:
	resume_requested.emit()


func _on_restart_pressed() -> void:
	restart_requested.emit()
